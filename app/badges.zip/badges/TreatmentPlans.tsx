// app/badges/TreatmentPlans.tsx
"use client";
import Section from "@/components/Section";

export default function TreatmentPlans({ uniqueContracts }: { uniqueContracts: number }) {
  const n = uniqueContracts || 0;
  const items = [
    { label: "Curious Patient",    desc: "10 contracts",    done: n >= 10 },
    { label: "Frequent Visitor",   desc: "20 contracts",    done: n >= 20 },
    { label: "Adaptive Case",      desc: "50 contracts",    done: n >= 50 },
    { label: "Onchain Specialist", desc: "100 contracts",   done: n >= 100 },
    { label: "Clinical Explorer",  desc: "500 contracts",   done: n >= 500 },
    { label: "Research Pioneer",   desc: "1000+ contracts", done: n >= 1000 },
  ];
  return <Section title="Treatment Plans" items={items} metricRight={`Unique: ${n}`} />;
}
