// app/badges/PatientHistory.tsx
"use client";
import Section from "@/components/Section";

export default function PatientHistory({ walletAge }: { walletAge: number }) {
  const items = [
    { label: "New Patient",    desc: "Wallet age ≥ 7 days",   done: walletAge >= 7  },
    { label: "Returning",      desc: "Wallet age ≥ 30 days",  done: walletAge >= 30 },
    { label: "Long-timer",     desc: "Wallet age ≥ 180 days", done: walletAge >= 180 },
    { label: "Veteran",        desc: "Wallet age ≥ 365 days", done: walletAge >= 365 },
    { label: "Two-year Club",  desc: "Wallet age ≥ 730 days", done: walletAge >= 730 },
    { label: "Three-year Pro", desc: "Wallet age ≥ 1095 days",done: walletAge >= 1095 },
  ];
  return <Section title="Patient History" items={items} />;
}
