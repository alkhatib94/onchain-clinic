// app/badges/CheckupFrequency.tsx
"use client";
import Section from "@/components/Section";

export default function CheckupFrequency({ activeDays }: { activeDays: number }) {
  const items = [
    { label: "Clinic Visitor I",   desc: "10 active days",   done: activeDays >= 10  },
    { label: "Clinic Visitor II",  desc: "20 active days",   done: activeDays >= 20  },
    { label: "Clinic Visitor III", desc: "30 active days",   done: activeDays >= 30  },
    { label: "Clinic Visitor IV",  desc: "50 active days",   done: activeDays >= 50  },
    { label: "Clinic Visitor V",   desc: "100 active days",  done: activeDays >= 100 },
    { label: "Clinic Visitor VI",  desc: "200 active days",  done: activeDays >= 200 },
  ];
  return <Section title="Checkup Frequency" items={items} metricRight={`Days: ${activeDays}`} />;
}
