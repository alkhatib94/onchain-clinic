"use client";
type Props = {
  uniswap?: number; sushi?: number; pancake?: number; aerodrome?: number;
  aave?: number; limitless?: number; stargate?: number; metamask?: number;
  lendingAny?: boolean; matcha?: number;
};
const LVL = [
  { name:"Uniswap Ward",   ok:(p:Props)=> (p.uniswap ?? 0)  >=3, desc:"Uniswap ≥ 3" },
  { name:"Sushi Ward",     ok:(p:Props)=> (p.sushi ?? 0)    >=3, desc:"Sushi ≥ 3" },
  { name:"Pancake Ward",   ok:(p:Props)=> (p.pancake ?? 0)  >=3, desc:"Pancake ≥ 3" },
  { name:"Aerodrome Ward", ok:(p:Props)=> (p.aerodrome ?? 0)>=3, desc:"Aerodrome ≥ 3" },
  { name:"Aave Ward",      ok:(p:Props)=> (p.aave ?? 0)     >=3, desc:"Aave ≥ 3" },
  { name:"Limitless Ward", ok:(p:Props)=> (p.limitless ?? 0)>=3, desc:"Limitless ≥ 3" },
  { name:"Stargate Ward",  ok:(p:Props)=> (p.stargate ?? 0) >=3, desc:"Stargate ≥ 3" },
  { name:"Metamask Ward",  ok:(p:Props)=> (p.metamask ?? 0) >=3, desc:"Metamask Swap/Bridge ≥ 3" },
  { name:"Lending Ward",   ok:(p:Props)=> !!p.lendingAny,        desc:"Lending protocols used" },
  { name:"Matcha Ward",    ok:(p:Props)=> (p.matcha ?? 0)   >=3, desc:"Matcha.xyz ≥ 3" },
];
export default function SpecialClinics(p: Props){
  const unlocked = LVL.filter(l=>l.ok(p)).length; const pct=Math.round(unlocked/LVL.length*100);
  return (
    <div className="rounded-2xl overflow-hidden border border-white/10 bg-black/20 h-full flex flex-col">
      <Header title="Special Clinics" />
      <div className="p-5 flex-1"><ul className="space-y-3">{LVL.map((l,i)=> <Row key={i} ok={l.ok(p)} idx={i+1} name={l.name} desc={l.desc} />)}</ul></div>
      <Progress unlocked={unlocked} total={LVL.length} pct={pct} color="from-teal-400 to-teal-200" />
    </div>
  );
}
function Header({title}:{title:string}) { return <div className="px-5 py-4 bg-white/5 border-b border-white/10"><div className="font-semibold">{title}</div></div>; }
function Row({ ok, idx, name, desc }: { ok: boolean; idx: number; name: string; desc: string }) {
  return (
    <li className={`flex items-center gap-3 px-3 py-3 rounded-xl border ${ok?"border-green-500/30 bg-green-500/5":"border-white/10"}`}>
      <div className={`w-7 h-7 rounded-md flex items-center justify-center text-xs ${ok?"bg-green-500/20 text-green-400 border border-green-500/40":"border border-white/15 text-white/40"}`}>{ok?"✓":idx}</div>
      <div className="flex-1"><div className="text-sm font-semibold">{name}</div><div className="text-xs opacity-70">{desc}</div></div>
      <div className={`text-xs ${ok?"text-green-400":"text-white/40"}`}>{ok?"Unlocked":"—"}</div>
    </li>
  );
}
function Progress({unlocked,total,pct,color}:{unlocked:number;total:number;pct:number;color:string}) {
  return (<>
    <div className="px-5 py-3 border-t border-white/10 text-xs flex items-center justify-between"><div>Progress</div><div>{unlocked}/{total} ({pct}%)</div></div>
    <div className="w-full h-1 bg-white/5"><div className={`h-1 bg-gradient-to-r ${color}`} style={{width:`${pct}%`}}/></div>
  </>);
}
