// app/badges/TreatmentCosts.tsx
"use client";
import Section from "@/components/Section";

export default function TreatmentCosts({ gasEth }: { gasEth: number }) {
  const g = gasEth || 0;
  const items = [
    { label: "Co-Pay Rookie",    desc: "≥ 0.005 ETH", done: g >= 0.005 },
    { label: "Co-Pay Novice",    desc: "≥ 0.01 ETH",  done: g >= 0.01 },
    { label: "Co-Pay Enthusiast",desc: "≥ 0.05 ETH",  done: g >= 0.05 },
    { label: "Co-Pay Pro",       desc: "≥ 0.1 ETH",   done: g >= 0.1 },
    { label: "Co-Pay Legend",    desc: "≥ 0.5 ETH",   done: g >= 0.5 },
    { label: "Co-Pay Whale",     desc: "≥ 1 ETH",     done: g >= 1 },
  ];
  return <Section title="Treatment Costs" items={items} metricRight={`Gas: ${g.toFixed(4)} ETH`} />;
}
