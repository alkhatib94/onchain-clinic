// app/badges/VitalSigns.tsx
"use client";
import Section from "@/components/Section";

export default function VitalSigns({ txCount }: { txCount: number }) {
  const items = [
    { label: "Pulse 50",   desc: "≥ 50 txs",   done: txCount >= 50  },
    { label: "Pulse 100",  desc: "≥ 100 txs",  done: txCount >= 100 },
    { label: "Pulse 200",  desc: "≥ 200 txs",  done: txCount >= 200 },
    { label: "Pulse 500",  desc: "≥ 500 txs",  done: txCount >= 500 },
    { label: "Pulse 1000", desc: "≥ 1000 txs", done: txCount >= 1000 },
    { label: "Pulse 5000", desc: "≥ 5000 txs", done: txCount >= 5000 },
  ];
  return <Section title="Vital Signs" items={items} metricRight={`TXs: ${txCount}`} />;
}
