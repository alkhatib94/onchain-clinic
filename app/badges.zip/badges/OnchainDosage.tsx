// app/badges/OnchainDosage.tsx
"use client";
import Section from "@/components/Section";

export default function OnchainDosage({ totalVolumeEth }: { totalVolumeEth: number }) {
  const v = totalVolumeEth || 0;
  const items = [
    { label: "Starter Dose",   desc: "≥ 0.1 ETH",  done: v >= 0.1 },
    { label: "Minor Patient",  desc: "≥ 0.5 ETH",  done: v >= 0.5 },
    { label: "Regular Treat.", desc: "≥ 1 ETH",    done: v >= 1 },
    { label: "Heavy Dose",     desc: "≥ 5 ETH",    done: v >= 5 },
    { label: "Chain Runner",   desc: "≥ 10 ETH",   done: v >= 10 },
    { label: "Intensive Care", desc: "≥ 25 ETH",   done: v >= 25 },
    // { label: "Onchain Titan", desc: "≥ 50 ETH",   done: v >= 50 }, // فعلها إذا بدك سابع
  ];
  return <Section title="Onchain Dosage" items={items} metricRight={`${v.toFixed(3)} ETH`} />;
}
