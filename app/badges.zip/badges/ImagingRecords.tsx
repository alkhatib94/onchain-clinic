// app/badges/ImagingRecords.tsx
"use client";
import Section from "@/components/Section";

export default function ImagingRecords({ nftCount }: { nftCount: number }) {
  const n = nftCount || 0;
  const items = [
    { label: "X-Ray I",     desc: "5 NFTs",    done: n >= 5 },
    { label: "X-Ray II",    desc: "10 NFTs",   done: n >= 10 },
    { label: "X-Ray III",   desc: "20 NFTs",   done: n >= 20 },
    { label: "CT Scan",     desc: "50+ NFTs",  done: n >= 50 },
    { label: "MRI Records", desc: "100+ NFTs", done: n >= 100 },
    { label: "Full Body",   desc: "500+ NFTs", done: n >= 500 },
  ];
  return <Section title="Imaging Records" items={items} metricRight={`NFTs: ${n}`} />;
}
