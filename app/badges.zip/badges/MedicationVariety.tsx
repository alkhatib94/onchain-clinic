// app/badges/MedicationVariety.tsx
"use client";
import Section from "@/components/Section";

export default function MedicationVariety({ erc20Count }: { erc20Count: number }) {
  const n = erc20Count || 0;
  const items = [
    { label: "Multi-Drug I",   desc: "5 ERC20",    done: n >= 5 },
    { label: "Multi-Drug II",  desc: "10 ERC20",   done: n >= 10 },
    { label: "Multi-Drug III", desc: "20 ERC20",   done: n >= 20 },
    { label: "Polypharmacy",   desc: "50+ ERC20",  done: n >= 50 },
    { label: "Chronic Meds",   desc: "100+ ERC20", done: n >= 100 },
    { label: "Experimental",   desc: "200+ ERC20", done: n >= 200 },
  ];
  return <Section title="Medication Variety" items={items} metricRight={`ERC20: ${n}`} />;
}
