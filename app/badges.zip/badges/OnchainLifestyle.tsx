// app/badges/OnchainLifestyle.tsx
"use client";
import Section from "@/components/Section";

function inRangeUTC(d: Date, h0: number, h1: number) {
  const h = d.getUTCHours();
  return h >= h0 && h < h1;
}
export default function OnchainLifestyle({
  txTimestampsUTC,
  mainnetLaunchUTC,
  holidayDatesUTC,
}: {
  txTimestampsUTC: string[];
  mainnetLaunchUTC: string;
  holidayDatesUTC: string[];
}) {
  const dates = (txTimestampsUTC || []).map(s => new Date(s));
  const anyMorning = dates.some(d => inRangeUTC(d, 6, 9));
  const anyNight   = dates.some(d => inRangeUTC(d, 0, 6));
  const m0 = new Date(mainnetLaunchUTC);
  const m7 = new Date(m0.getTime() + 7 * 86400000);
  const firstWeek = dates.some(d => d >= m0 && d < m7);
  const holidays = new Set(holidayDatesUTC || []);
  const onHoliday = (txTimestampsUTC || []).some(iso => holidays.has(iso.slice(0,10)));
  // 10+ txs في يوم UTC واحد
  const byDay: Record<string, number> = {};
  for (const iso of txTimestampsUTC || []) {
    const day = iso.slice(0,10);
    byDay[day] = (byDay[day] || 0) + 1;
  }
  const day10 = Object.values(byDay).some(c => c >= 10);

  const items = [
    { label: "Morning Checkup",    desc: "Transaction between 6–9am UTC",           done: anyMorning },
    { label: "Night Shift",        desc: "Transaction between 00–06am UTC",          done: anyNight },
    { label: "First Admission",    desc: "Interacted in first week of mainnet",      done: firstWeek },
    { label: "Doctor’s Day Rounds",desc: "Transaction on March 30",                  done: onHoliday },
    { label: "Emergency Case",     desc: "Transaction on a global holiday",          done: onHoliday },
    { label: "Intensive Care",     desc: "10+ transactions in one UTC day",          done: day10 },
  ];
  return <Section title="Onchain Lifestyle" items={items} />;
}
