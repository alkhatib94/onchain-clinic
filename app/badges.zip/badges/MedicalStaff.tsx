// app/badges/MedicalStaff.tsx
"use client";
import Section from "@/components/Section";

export default function MedicalStaff({ deployedContracts }: { deployedContracts: number }) {
  const n = deployedContracts || 0;
  const items = [
    { label: "Resident I",     desc: "Deploy ≥ 3 contracts",   done: n >= 3 },
    { label: "Resident II",    desc: "Deploy ≥ 5 contracts",   done: n >= 5 },
    { label: "Resident III",   desc: "Deploy ≥ 10 contracts",  done: n >= 10 },
    { label: "Senior Resident",desc: "Deploy ≥ 20 contracts",  done: n >= 20 },
    { label: "Attending Doctor",desc:"Deploy ≥ 50 contracts",  done: n >= 50 },
    { label: "Chief Surgeon",  desc: "Deploy ≥ 100 contracts", done: n >= 100 },
  ];
  return <Section title="Medical Staff" items={items} metricRight={`Deployed: ${n}`} />;
}
