// app/badges/OnchainLifestyle.tsx
"use client";

type Props = {
  txTimestampsUTC?: string[];
  mainnetLaunchUTC?: string;
  holidayDatesUTC?: string[];
};

export default function OnchainLifestyle({
  txTimestampsUTC = [],
  mainnetLaunchUTC = "2023-08-09T00:00:00Z",
  holidayDatesUTC = [],
}: Props) {
  // حراسات إضافية
  const txs = Array.isArray(txTimestampsUTC) ? txTimestampsUTC : [];
  const holidays = Array.isArray(holidayDatesUTC) ? holidayDatesUTC : [];

  // أي .map أو .filter يشتغل على txs/holidays فقط
  const activeDays = txs
    .map((ts) => {
      const d = new Date(ts);
      return Number.isNaN(+d) ? null : d.toISOString().slice(0, 10);
    })
    .filter((d): d is string => !!d);

  const uniqueDays = new Set(activeDays).size;
  const hadHolidayActivity = activeDays.some((d) => holidays.includes(d));

  return (
    <section className="rounded-2xl border border-white/10 bg-black/20 p-5">
      <div className="text-sm font-semibold mb-1">Onchain Lifestyle</div>
      <div className="text-xs opacity-75">
        Since: {new Date(mainnetLaunchUTC).toISOString().slice(0, 10)} • Active unique days: {uniqueDays}{" "}
        {hadHolidayActivity ? "• 🎉 Holiday activity detected" : ""}
      </div>
    </section>
  );
}
