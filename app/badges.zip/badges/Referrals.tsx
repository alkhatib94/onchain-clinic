// app/badges/Referrals.tsx
"use client";
import Section from "@/components/Section";

export default function Referrals({
  usedThirdPartyBridge, usedNativeBridge,
  relayCount, jumperCount, bungeeCount, acrossCount,
}: {
  usedThirdPartyBridge: boolean; usedNativeBridge: boolean;
  relayCount: number; jumperCount: number; bungeeCount: number; acrossCount: number;
}) {
  const items = [
    { label: "Third-party Referral", desc: "Used 3rd party bridge",    done: !!usedThirdPartyBridge },
    { label: "Native Referral",      desc: "Used official Base bridge", done: !!usedNativeBridge },
    { label: "Relay Checkup",        desc: "Relay ≥ 3",                 done: (relayCount||0)   >= 3 },
    { label: "Jumper Checkup",       desc: "Jumper ≥ 3",                done: (jumperCount||0)  >= 3 },
    { label: "Bungee Checkup",       desc: "Bungee ≥ 3",                done: (bungeeCount||0)  >= 3 },
    { label: "Across Checkup",       desc: "Across ≥ 3",                done: (acrossCount||0)  >= 3 },
  ];
  return <Section title="Referrals" items={items} />;
}
